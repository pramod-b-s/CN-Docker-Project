/* This file is auto generated, version 201410060605 */
/* SMP */
#define UTS_MACHINE "i386"
#define UTS_VERSION "#201410060605 SMP Mon Oct 6 10:57:55 UTC 2014"
#define LINUX_COMPILE_BY "apw"
#define LINUX_COMPILE_HOST "gomeisa"
#define LINUX_COMPILER "gcc version 4.6.3 (Ubuntu/Linaro 4.6.3-1ubuntu5) "
